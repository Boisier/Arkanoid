# pragma once

void initGame();